num = 1
for num in range (1,1000):
	if num % 2 == 1:
		print num