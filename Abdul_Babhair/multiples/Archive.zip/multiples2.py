num = 5
for num in range (5,1000000):
	if num % 5 == 0:
		print num