for count in range (1,1000):
    if count%2!=0:
        print count
